# ICT Mobile Trader — Android prototype

This is the first mobile UI build for the requested phone trading bot.

## Included
- Android native project
- XAUUSD / NAS100 focus
- Risk and RR fields
- Signal display
- AUTO ON / STOP / CLOSE ALL controls
- Signal server URL + token fields

## Important
The Android MT4/MT5 mobile apps do not execute EAs. This app is a control panel. Automatic order execution requires a secure bridge/server connected to a broker terminal or broker API.

Do not enter your broker password into this app.

## Build
Open this folder in Android Studio and build an APK. The environment used to create this source does not have the Android Gradle plugin cache, so an APK could not be compiled here offline.
