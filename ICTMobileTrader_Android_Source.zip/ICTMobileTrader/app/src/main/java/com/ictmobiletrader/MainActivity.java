package com.ictmobiletrader;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root; TextView status, signal, detail; EditText server, token, risk, rr;
  Button auto, stop;
  int pad=16;
  TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(0,8,0,8); return t; }
  EditText edit(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(150,160,185)); e.setTextColor(Color.WHITE); e.setSingleLine(); e.setPadding(12,4,12,4); return e; }
  Button btn(String text){ Button b=new Button(this); b.setText(text); return b; }
  void card(View v){ v.setBackgroundColor(Color.rgb(21,28,49)); v.setPadding(pad,pad,pad,pad); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,8,0,8); root.addView(v,lp); }
  public void onCreate(Bundle b){super.onCreate(b); build();}
  void build(){
    ScrollView sv=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad,pad,pad,pad); root.setBackgroundColor(Color.rgb(11,16,32)); sv.addView(root); setContentView(sv);
    root.addView(tv("ICT Mobile Trader",25)); root.addView(tv("XAUUSD • NAS100 • Mobile control panel",13));
    LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); status=tv("●  Disconnected",16); c.addView(status); server=edit("Signal server URL"); c.addView(server); token=edit("API token"); token.setInputType(129); c.addView(token); Button connect=btn("CONNECT"); c.addView(connect); card(c);
    LinearLayout a=new LinearLayout(this); a.setOrientation(LinearLayout.VERTICAL); a.addView(tv("Risk & Execution",18)); risk=edit("Risk % (default 0.30)"); risk.setText("0.30"); a.addView(risk); rr=edit("Reward / Risk (default 2.0)"); rr.setText("2.0"); a.addView(rr); a.addView(tv("Symbols: XAUUSD / NAS100",13)); card(a);
    LinearLayout s=new LinearLayout(this); s.setOrientation(LinearLayout.VERTICAL); s.addView(tv("Latest Signal",14)); signal=tv("WAITING",24); s.addView(signal); detail=tv("No signal received",13); s.addView(detail); card(s);
    LinearLayout ctl=new LinearLayout(this); ctl.setOrientation(LinearLayout.HORIZONTAL); auto=btn("AUTO ON"); stop=btn("STOP"); ctl.addView(auto,new LinearLayout.LayoutParams(0,-2,1)); ctl.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); card(ctl); Button close=btn("CLOSE ALL POSITIONS"); root.addView(close);
    connect.setOnClickListener(v->{status.setText("●  Bridge configured");}); auto.setOnClickListener(v->{signal.setText("AUTO ON");detail.setText("Execution enabled — bridge required");}); stop.setOnClickListener(v->{signal.setText("STOPPED");detail.setText("Automatic execution disabled");}); close.setOnClickListener(v->Toast.makeText(this,"CLOSE_ALL command requires the connected bridge.",Toast.LENGTH_LONG).show());
  }
}
