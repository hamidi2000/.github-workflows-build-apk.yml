from flask import Flask, request, jsonify
import os, time, uuid
app=Flask(__name__)
TOKEN=os.getenv('ICT_API_TOKEN','CHANGE_ME')
latest=None; enabled=False; commands=[]
def ok(): return request.headers.get('Authorization','') == 'Bearer '+TOKEN
@app.get('/health')
def health(): return jsonify(ok=True,service='ICT Mobile Trader Bridge',enabled=enabled)
@app.get('/signal')
def signal():
    if not ok(): return jsonify(error='unauthorized'),401
    return jsonify(latest or {'action':'WAIT'})
@app.post('/signal')
def set_signal():
    global latest
    if not ok(): return jsonify(error='unauthorized'),401
    d=request.get_json(silent=True) or {}
    if d.get('action') not in ('BUY','SELL','WAIT'): return jsonify(error='action must be BUY, SELL or WAIT'),400
    if d.get('action')!='WAIT' and not all(k in d for k in ('symbol','sl','tp')): return jsonify(error='symbol/sl/tp required'),400
    d['id']=str(uuid.uuid4()); d['time']=int(time.time()); latest=d
    return jsonify(ok=True,signal=d)
@app.post('/command')
def command():
    global enabled
    if not ok(): return jsonify(error='unauthorized'),401
    d=request.get_json(silent=True) or {}; a=str(d.get('action','')).upper()
    if a=='START': enabled=True
    elif a=='STOP': enabled=False
    elif a=='CLOSE_ALL': pass
    else: return jsonify(error='unknown command'),400
    commands.append({'action':a,'time':int(time.time())})
    return jsonify(ok=True,enabled=enabled,action=a)
@app.get('/state')
def state():
    if not ok(): return jsonify(error='unauthorized'),401
    return jsonify(enabled=enabled,latest=latest,commands=commands[-20:])
if __name__=='__main__': app.run('0.0.0.0',8080)
