#property strict
#property version "1.00"
#include <Trade/Trade.mqh>
CTrade trade;
input string BridgeURL="https://YOUR-SERVER.example.com";
input string ApiToken="CHANGE_ME";
input double RiskPercent=0.30;
input int PollSeconds=3;
input long Magic=26091401;
input int MaxSpreadPoints=80;
string lastId="";
string Field(string j,string k){string q="\""+k+"\"";int p=StringFind(j,q);if(p<0)return "";p=StringFind(j,":",p);if(p<0)return "";p++;while(p<StringLen(j)&&(StringGetCharacter(j,p)==' '||StringGetCharacter(j,p)=='\"'))p++;int e=p;while(e<StringLen(j)&&StringGetCharacter(j,e)!=','&&StringGetCharacter(j,e)!='}'&&StringGetCharacter(j,e)!='\"')e++;return StringSubstr(j,p,e-p);}
bool Get(string path,string &out){char data[],res[];string h="Authorization: Bearer "+ApiToken+"\r\n";string rh;int c=WebRequest("GET",BridgeURL+path,h,4000,data,res,rh);if(c!=200)return false;out=CharArrayToString(res);return true;}
double Lots(string s,double e,double sl){double money=AccountInfoDouble(ACCOUNT_EQUITY)*RiskPercent/100.0,ts=SymbolInfoDouble(s,SYMBOL_TRADE_TICK_SIZE),tv=SymbolInfoDouble(s,SYMBOL_TRADE_TICK_VALUE);if(ts<=0||tv<=0)return 0;double l=money/(MathAbs(e-sl)/ts*tv),mn=SymbolInfoDouble(s,SYMBOL_VOLUME_MIN),mx=SymbolInfoDouble(s,SYMBOL_VOLUME_MAX),st=SymbolInfoDouble(s,SYMBOL_VOLUME_STEP);l=MathMax(mn,MathMin(mx,l));if(st>0)l=MathFloor(l/st)*st;return l;}
void Poll(){string state,sig;if(!Get("/state",state)||Field(state,"enabled")!="true")return;if(!Get("/signal",sig))return;string id=Field(sig,"id");if(id==""||id==lastId)return;string a=Field(sig,"action"),s=Field(sig,"symbol");double sl=StringToDouble(Field(sig,"sl")),tp=StringToDouble(Field(sig,"tp"));if((a!="BUY"&&a!="SELL")||s==""||sl<=0||tp<=0)return;SymbolSelect(s,true);double ask=SymbolInfoDouble(s,SYMBOL_ASK),bid=SymbolInfoDouble(s,SYMBOL_BID),pt=SymbolInfoDouble(s,SYMBOL_POINT);if(pt<=0||(ask-bid)/pt>MaxSpreadPoints)return;double e=a=="BUY"?ask:bid,l=Lots(s,e,sl);if(l<=0)return;trade.SetExpertMagicNumber(Magic);trade.SetDeviationInPoints(20);bool r=false;if(a=="BUY"&&sl<e)r=trade.Buy(l,s,0,sl,tp,"ICT Mobile BUY");if(a=="SELL"&&sl>e)r=trade.Sell(l,s,0,sl,tp,"ICT Mobile SELL");if(r)lastId=id;}
int OnInit(){EventSetTimer(MathMax(1,PollSeconds));return INIT_SUCCEEDED;}void OnDeinit(const int r){EventKillTimer();}void OnTimer(){Poll();}
