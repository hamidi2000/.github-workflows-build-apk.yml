# ICT Mobile Trader Bridge v1

Flow: Android app -> HTTPS Bridge -> MT5 Desktop/VPS -> Broker.

## Server
Set a strong environment variable `ICT_API_TOKEN`, then run:
`pip install -r requirements.txt`
`gunicorn -b 0.0.0.0:8080 app:app`

Endpoints:
- GET /health
- GET /signal
- POST /signal
- POST /command
- GET /state

All except /health use `Authorization: Bearer YOUR_TOKEN`.

## MT5
Compile `mt5/ICTMobileBridge.mq5` in MetaEditor, attach it to a chart, and add the Bridge URL under Tools > Options > Expert Advisors > Allow WebRequest.
Set the same token in the EA.

**Test on demo first.** This is an execution bridge, not a profitable strategy by itself. Do not put broker passwords in the mobile app.
